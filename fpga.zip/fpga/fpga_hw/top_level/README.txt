Directory: de0nano
Use: MDA DE0nano FPGA
Author: Mark Harfouche
Editors:


This directory holds a Quartus 2 Project for the DE0 nano board.
It also includes the SOPC for the DE0 nano

