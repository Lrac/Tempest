Directory: fpga_sw
Use: FPGA embedded C code
Author: Victor Zhang
Editors: Anthony De Caria

This directory should hold the C code for the navigation board (The FPGA) running the nios2.

It depends on the stuff in the BSP directory to properly compile. 

In addition, we have in this folder our assembly code to collect data from the AD7264s.
