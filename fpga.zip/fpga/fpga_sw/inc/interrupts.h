#ifndef _MDA_INTERRUPTS_H
#define _MDA_INTERRUPTS_H

int get_user_depth();
void set_controller(int);
void init_interrupts();

#endif
